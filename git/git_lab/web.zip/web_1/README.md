# Git Web Demo - Multi Commit

Repo ini dibuat untuk latihan **merge**, **rebase**, dan **cherry-pick** dengan banyak commit di tiap branch.

## Cara pakai
1. Clone / extract repo ini
2. Jalankan `bash setup-branches.sh` (pakai Git Bash)
3. Lihat branch dan commit history dengan:
   ```bash
   git log --graph --all --oneline
   ```
