#!/bin/bash
git init
git checkout -b main
git add .
git commit -m "Initial commit: basic layout"

# Tambah commit bertahap di main
for step in 1 2 3; do
    echo "<p>Main branch update $step</p>" >> index.html
    git commit -am "Main branch update $step"
done

# feature-header-color
git checkout -b feature-header-color main
for color in red blue green orange purple; do
    sed -i "s/background-color: .*/background-color: $color;/" style.css
    git commit -am "Change header color to $color"
done

# feature-footer
git checkout -b feature-footer main
for update in "Added footer text" "Changed footer bg to yellow" "Added footer link" "Changed footer font size"; do
    case "$update" in
        "Added footer text")
            echo "<p>Extra footer text</p>" >> index.html
            ;;
        "Changed footer bg to yellow")
            sed -i "s/footer {[^}]*/footer { background-color: yellow;/" style.css
            ;;
        "Added footer link")
            echo "<a href='#'>Footer link</a>" >> index.html
            ;;
        "Changed footer font size")
            echo "footer { font-size: 18px; }" >> style.css
            ;;
    esac
    git commit -am "$update"
done

# # merge-conflict-demo
# git checkout -b merge-conflict-demo main
# for text in "Conflict change 1" "Conflict change 2" "Conflict change 3"; do
#     sed -i "s/This is the main branch layout./$text/" index.html
#     git commit -am "$text"
# done

# rebase-demo
git checkout -b rebase-demo main~2
for num in 1 2 3 4; do
    echo "<p>Rebase demo content $num</p>" >> index.html
    git commit -am "Add rebase demo content $num"
done

# cherry-pick-demo
git checkout -b cherry-pick-demo main
for msg in "Cherry change A" "SPECIAL cherry-pick commit" "Cherry change B"; do
    echo "<p>$msg</p>" >> index.html
    git commit -am "$msg"
done

git checkout main
echo "Setup complete. Branches created:"
git branch --list
